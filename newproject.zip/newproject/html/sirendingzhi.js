function nextStep(){
if($("#validateWillAddress").text()!=""){
		return ;
}
$(".oneDiv").css("display","none");
$(".twoDiv").css("display","block");
}
function validateWillAdress(){
	var willCity = $("#willAddress").val();
	if(willCity==""){
		$("#validateWillAddress").text("请输入目的地");
		return ;
	}
	if(willCity.length>50){
		$("#validateWillAddress").text("最大长度为50");
		return ;
	}
	$("#validateWillAddress").text("");
	
}
function getHotDestination(th){
	$("#willAddress").val($(th).text());
}
function gotwoStep(){
	$(".twoDiv").css("display","block");
	$(".threeDiv").css("display","none");
}
function submitOrder(){
	//提交定制订单
		var willCity = $("#willAddress").val();
		var GoCity = $("#GoAddress").val();
		var goodsDepartTime =  $("#start").val();//开始时间
		var orderBackTime =  $("#end").val();//返回时间
		var personNum = $("#PersonNum").val();
		var perName = $("#PerName").val();
		var perPhone = $("#PerPhone").val();
		 
	
		if(goodsDepartTime.length == 0){
//			$("#AddressPopText").css('display','none');
			$("#AddressPopText2").css('display','block');
		}
		if(orderBackTime.length == 0){
//			$("#AddressPopText").css('display','none');
			$("#AddressPopText2").css('display','block');
		}
		if(GoCity.length == 0){
//			$("#AddressPopText2").css('display','none');
			$("#AddressPopText3").css('display','block');
		}
		if(perName.length == 0){
//			$("#AddressPopText3").css('display','none');
			$("#AddressPopText4").css('display','block');
		}
		if(perPhone.length == 0){
//			$("#AddressPopText4").css('display','none');
			$("#AddressPopText5").css('display','block');
		}
		if(!(/^1[3|4|5|8|7][0-9]\d{8}$/.test(perPhone))){ 
			$("#AddressPopText5").css('display','block');
			$("#AddressPopText5").html("手机号格式不正确");
	    } 
		
		
		
		if(willCity.length != 0 && goodsDepartTime.length != 0 && orderBackTime.length != 0 && GoCity.length != 0 && perName.length != 0 && perPhone.length != 0 && (/^1[3|4|5|8|7][0-9]\d{8}$/.test(perPhone))){
//	    	$("#AddressPopText5").css('display','none');
			$.ajax({
				type:'post',
				url:MainUrl+"/personalOrder/savePersonalOrder.do",
				data:{
					'destination':willCity,
					'goCity':GoCity,
					'departureTime':goodsDepartTime,
					'backTime':orderBackTime,
					'personNum':personNum,
					'linkName':perName,
					'linkPhone':perPhone,
				},
				success:function(m){
					if(m=="1"){
						createPopDiv2("提示",m.message);
						$(".threeDiv").css("display","none");
						$(".fourDiv").css("display","block");
//						setTimeout("location.reload()",)
					}else{
						$(".threeDiv").css("display","none");
						$(".fiveDiv").css("display","block");
						createPopDiv("提示",m.message);
					}
				},
				error:function(e){
					createPopDiv("提示","网络错误");
				}
			});
		}
		
}