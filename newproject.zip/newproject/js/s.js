 $(function() {

     getProductDetail();


 });

 function getProductDetail() {
     var str = location.search;
     if (str == "") {
         return;
     }
     var proId = str.split("?")[1].split("=")[1];
     $.ajax({
         type: 'post',
         url: MainUrl + '/product/getProductInfo.do',
         data: {
             'productId': proId,

         },
         success: function(m) {
             if (!Array.prototype.forEach) {

                 Array.prototype.forEach = function forEach(callback, thisArg) {

                     var T, k;

                     if (this == null) {
                         throw new TypeError("this is null or not defined");
                     }
                     var O = Object(this);
                     var len = O.length >>> 0;
                     if (typeof callback !== "function") {
                         throw new TypeError(callback + " is not a function");
                     }
                     if (arguments.length > 1) {
                         T = thisArg;
                     }
                     k = 0;

                     while (k < len) {

                         var kValue;
                         if (k in O) {

                             kValue = O[k];
                             callback.call(T, kValue, k, O);
                         }
                         k++;
                     }
                 };
             }
             var productDetail = m.productDetail;
             var orderCommentList = m.orderComment;
             var logoHtml = "";
             logoHtml += '<div class="left fl"><h1>' + productDetail.productName + '</h1> <h1>' + productDetail.productTitle + '</h1><h5>' + productDetail.travelProfile + '</h5>';
             logoHtml += '<div class="left-bot"><p><span>产品ID：<em id="product_id">' + productDetail.productId + '</em></span></p>'
             logoHtml += '<table><tbody><tr class="first"><td class="td_77">旅行天数</td><td class="td_204">交通工具</td><td style="padding:0 12px;">出发城市</td><td class="mf">最低价格</td><td rowspan="2" class="mf"><a href="javascript:goReserveProduct(' + productDetail.productId + ');" id="scheduled"></a></td></tr>'
             logoHtml += '<td>' + productDetail.travelDays + 'D</td><td style="margin-left: 15px;"><a href="#" class="fly"></a><a href="#" class="bus"></a><a href="#" class="train"></a><a href="#" class="ship"></a></td><td style="padding:0 12px;font-size: 12px;">' + productDetail.goCity + '</td><td class="money"><span>￥' + productDetail.minprice + '/</span>人起</td></tr></tbody></table></div></div>'
             logoHtml += ' <div class="right fr"><div class="flg"></div><div class="face"><a href=""><img src="../../images/face.jpg"></a></div><dl><dt>' + m.guide.name + '</dt><dd class="d1">营养师 | 瑜伽教练</dd><dd>' + productDetail.travelContent + '</dd></dl></div>';
             $(".logo").find(".container").html(logoHtml);
             var seasonhtml = '<dl> <dd><span class="c ' + (productDetail.suitableSeason == "春天" ? "active" : "") + '"></span><span class="x ' + (productDetail.suitableSeason == "夏天" ? "active" : "") + '"></span><span class="q ' + (productDetail.suitableSeason == "秋天" ? "active" : "") + '"></span><span class="d ' + (productDetail.suitableSeason == "冬天" ? "active" : "") + '"></span></dd><dt><span>健康养生|结伴旅行</span></dt></dl>';
             $(".season").html(seasonhtml);

             var productOutlineHtml = "";
             productOutlineHtml += ' <dl><dt> <span class="s1"></span> </dt><dd><h1>' + productDetail.productOutline.activity + '</h1><h2>' + productDetail.productOutline.activityDescribe + '</h2></dd></dl>';
             productOutlineHtml += ' <dl><dt> <span class="s2"></span> </dt><dd><h1>' + productDetail.productOutline.hotel + '</h1><h2>' + productDetail.productOutline.hotelDescribe + '</h2></dd></dl>';
             productOutlineHtml += ' <dl><dt> <span class="s3"></span> </dt><dd><h1>' + productDetail.productOutline.healthelement + '</h1><h2>' + productDetail.productOutline.healthelementDescribe + '</h2></dd></dl>';
             productOutlineHtml += ' <dl><dt> <span class="s4"></span> </dt><dd><h1>' + productDetail.productOutline.scenicspot + '</h1><h2>' + productDetail.productOutline.scenicspotDescribe + '</h2></dd></dl>';
             productOutlineHtml += ' <dl><dt> <span class="s5"></span> </dt><dd><h1>' + productDetail.productOutline.food + '</h1><h2>' + productDetail.productOutline.foodDescribe + '</h2></dd></dl>';
             productOutlineHtml += ' <dl><dt> <span class="s6"></span> </dt><dd><h1>' + productDetail.productOutline.trafficTime + '</h1><h2>' + productDetail.productOutline.trafficTimeDescribe + '</h2></dd></dl>';
             $(".pro-overview").html(productOutlineHtml);


             var baseTrilHtml = '<ul class="clearfix">';
             var baseTrilContentHtml = '';
             for (var i = 0; i < productDetail.productTripList.length; i++) {
                 baseTrilHtml += '<li style="padding-left: 51px;"><span></span><p>D' + ((i + 1) < 10 ? "0" + (i + 1) : (i + 1)) + '</p><p>' + productDetail.productTripList[i].mainDestination + '</p></li>';
                 baseTrilContentHtml += ' <div class="day" id="d' + (i) + '"><h3>第' + (i + 1) + '天</h3><b></b><h4>' + productDetail.productTripList[i].tripName + '</h4></div>';
                 baseTrilContentHtml += '<div class="content"><div class="line"></div><ul>'

                 for (var j = 0; j < productDetail.productTripList[i].tripDetailList.length; j++) {
                     baseTrilContentHtml += '<li>';
                     baseTrilContentHtml += '<span>' + productDetail.productTripList[i].tripDetailList[j].timePoint + '</span><em class="fly_ico"></em><p>' + productDetail.productTripList[i].tripDetailList[j].activityTitle + '</p><p>' + productDetail.productTripList[i].tripDetailList[j].activityDescribe + '</p>'
                     baseTrilContentHtml += '<div class="productimg"><a href="javascript:;"><img src="../../images/product_img2.jpg"></a><a href="javascript:;"><img src="../../images/product_img2.jpg"></a><a href="javascript:;"><img src="../../images/product_img2.jpg"></a><a href="javascript:;"><img src="../../images/product_img2.jpg"></a></div>';
                     baseTrilContentHtml += '</li>';
                 }
                 baseTrilContentHtml += '</ul>';
             }
             baseTrilHtml += '</ul></div>';
             $(".basictravel").html(baseTrilHtml); //基本行程
             $(".timeline").html(baseTrilContentHtml); //详细行程
             var feeInclude = "";
             var feeNotIncludeHtml = '';
             for (var i = 0; i < productDetail.costDescription.costDescriptionInclude.length; i++) {
                 feeInclude += '<li>' + (i + 1) + '、' + productDetail.costDescription.costDescriptionInclude[i].costDescription + '</li>';
             }

             $(".feeInclude").find("ol").html(feeInclude);
             for (var i = 0; i < productDetail.costDescription.costDescriptionNotInclude.length; i++) {
                 feeNotIncludeHtml += '<li>' + (i + 1) + '、' + productDetail.costDescription.costDescriptionNotInclude[i].costDescription + '</li>';
             }
             $(".feeNotInclude").find("ol").html(feeNotIncludeHtml);
             var reserveHtml = '';
             reserveHtml += '<h5>出团通知：</h5><ol><li>' + productDetail.bookingNotice.groupNotice + '</li></ol>';
             reserveHtml += '<h5>意见反馈：</h5><ol><li>' + productDetail.bookingNotice.feedback + '</li></ol>';
             reserveHtml += '<h5>活动说明：</h5><ol><li>' + productDetail.bookingNotice.activityDescription + '</li></ol>';
             reserveHtml += '<h5>温馨提示：</h5><ol>';
             for (var i = 0; i < productDetail.bookingNotice.reminderVoList.length; i++) {
                 reserveHtml += '<li>' + (i + 1) + '.' + productDetail.bookingNotice.reminderVoList[i].content + '</li>';
             }
             reserveHtml += '</ol>';
             $(".reserveNotice").html(reserveHtml);
             var orderCommentHtml = "";

             $("#commentNum").text(orderCommentList.length);
             for (var i = 0; i < orderCommentList.length; i++) {
                 orderCommentHtml += ' <dl class="clearfix"><dt><a href=""><img src="../../images/face.jpg"></a></dt>';
                 orderCommentHtml += ' <dd><ul><li><div>满意度<span></span></div><div data-score="1"></div></li><li>' + orderCommentList[i].experience + '</li><li>导游服务： ' + orderCommentList[i].guideService + '</li></ul></dd>';
                 orderCommentHtml += ' <dd class="last"><p>来自游客<span id="mobile">***' + (orderCommentList[i].commentPerson.substring(8, 12)) + '</span> <span id="date">' + orderCommentList[i].createTime + '</span></p></dd></dl>';
             }

             $(".evaluation").html(orderCommentHtml);


             var getBodyW = function() {
                 return document.body.offsetWidth;
             };
             var getBodyH = function() {
                 return document.body.offsetHeight;
             };
             var getElTop = function(el) {
                 return el.offsetTop;
             };
             var g = function(id) {
                 return document.getElementById(id);
             }
             var scrollTopTo = function(to) {
                 var start = document.body.scrollTop;
                 fx(function(now, type) {
                     window.scroll(0, now);
                 }, start, to);
             }
             var show = function(obj) {

                 var top = getElTop(g(obj));
                 scrollTopTo(top);
                 //  滚动到当前的位置
             }




             if ($(".timeline .content").length > 0) {
                 var li = "";
                 for (var i = 0; i < $(".timeline .content").length; i++) {
                     li = "<li>第" + parseInt(i + 1) + "天</li>";
                     $("#timelinenav").append(li)
                 }

             }





             /*var $g = $(g('timelinenav'));
		    alert( $g.find("li").length)
		    $g.find("li").eq(0).addClass("active");
		    $g.find("li").click(function() {

		        show("d" + $(this).index());

		        $(this).addClass("active").siblings().removeClass("active");
		    });
*/

             $("#location li").not(".last").click(function() {

                 //alert($(this).index())
                 alert(show("d1"));
                 alert($("#d1"))
                 $(this).parent().addClass("active").siblings().removeClass("active");
             });

             window.onscroll = function() {

                 var top = document.body.scrollTop;

                 if (top > 200) {
                     g('timelinenav').style.position = 'fixed';
                     // g('timelinenav').style.left = (getBodyW()-960)/2+ 'px';
                     g('timelinenav').style.left = 30 + 'px';
                     // g('timelinenav').style.top  = '60px';
                 } else {
                     g('timelinenav').style.position = '';
                     g('timelinenav').style.left = '';
                     g('timelinenav').style.top = '';
                 }


             }
             var flag = false;
             $.each($(".content li"), function() {
                 $(this).find("p").click(function() {
                     if (!flag) {
                         $(this).siblings(".productimg").slideDown();
                         flag = true;
                     } else {
                         $(this).siblings(".productimg").slideUp();


                         flag = false;
                     }
                 })
             })






             //分页
             $("div.holder").jPages({
                 containerID: "itemContainer",
                 previous: "上一页",
                 next: "下一页",
                 perPage: 3,
                 callback: function(pages, items) {
                     $("#countpage").html(pages.count);
                 }
             });

             /* when button is clicked */
             $("#jumptopage").click(function() {
                 /* get given page */
                 var page = parseInt($("input").val());

                 /* jump to that page */
                 $("div.holder").jPages(page);

             });


             var recommendedHtml = "";
             for (var i = 0; i < m.healthProduct.length; i++) {
                 recommendedHtml += ' <li class=' + (i == 2 ? "last" : "") + '>';
                 recommendedHtml += '<div class="img"> <a href=""><img src="../../images/re_pro1.jpg"></a><dl><dt>' + m.healthProduct[i].name + '</dt><dd class="red"></dd><dd class="vip"><span>会员价</span><em>￥' + m.healthProduct[i].memberPrice + '</em></dd><dd class="normal">￥' + m.healthProduct[i].marketPrice + '</dd></dl> <div></div></div>';
                 recommendedHtml += '</li>';
             }
             $(".recommended").html(recommendedHtml);



             var dlLen = $("#itemContainer>dl");

             for (var i = 0; i < dlLen.length; i++) {
                 $("#itemContainer>dl").eq(i).find("li").eq(0).find("div").eq(1).attr("id", "star" + i);
                 $("#itemContainer>dl").eq(i).find("li").eq(0).find("div").eq(0).find("span").attr("id", "result" + i);
                 var star = $("#itemContainer>dl").eq(i).find("li").eq(0).find("div").eq(1).attr("id");
                 var result = $("#itemContainer>dl").eq(i).find("li").eq(0).find("div").eq(0).find("span").attr("id");

                 $("#" + star).raty({
                     number: 5, //多少个星星设置
                     score: 0, //初始值是设置
                     targetType: 'number', //类型选择，number是数字值，hint，是设置的数组值
                     path: '../../bower_components/jquery-raty/img',

                     size: 24,
                     starHalf: 'star-half.png',
                     starOff: 'star-off.png',
                     starOn: 'star-on.png',
                     target: '#' + result,
                     cancel: false,
                     targetKeep: true,
                     precision: true, //是否包含小数
                     click: function(score, evt) {
                         $("#result").show();
                         alert('ID: ' + $(this).attr('id') + "\nscore: " + score + "\nevent: " + evt.type);
                     }
                 });
             }





             $.each($("table .last"), function() {
                 if ($(this).find("td").eq(2).text().length == 2) {

                     $(this).find("td").eq(2).css({
                         "font-size": "30px"
                     });
                 }
             });


             $("#location li").not(".last").find("span").click(function() {
                 $(this).parent().addClass("active").siblings().removeClass("active");
             });


             (function() {
                 $(window).scroll(function() {
                     if ($(window).scrollTop() > 100) {
                         $(".returntop").fadeIn(800);
                     } else {
                         $(".returntop").fadeOut(800);
                     }
                 });
                 $("#returntop").click(function() {
                     $("html, body").animate({
                         scrollTop: 0
                     }, 800);
                 })

             })();
             (function() {
                 $(window).scroll(function() {
                     if ($(window).scrollTop() > 2700) {
                         $("#timelinenav").fadeIn(800);
                     } else {
                         $("#timelinenav").fadeOut(800);
                     }
                 });


             })();

         },


         error: function(e) {
             //			alert("网络错误")
         }
     })

 }
 //跳转到商品预定页面
 function goReserveProduct(id) {
     window.open("productreservations.html?proid=" + id);

 }
