var REG = {
    regMobile : /^1[3|4|5|7|8]\d{9}$/,
    regEmail : /^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/

};





/*
    dis:  向select option填充内容  
    arrObj: 数据流
    idObj：对象

*/

function getSelectVal(arrObj, idObj) {
    $.each(arrObj, function(s) {
        $(idObj).append('<option value="' + s + '">' + arrObj[s] + '</option>');
    });
}

/*
    全选

*/

function getAllcheckbox(obj, ele) {
    $(obj).click(function() {
        if ($(this).prop("checked", "checked")) {
            $(ele).each(function() {
                $(this).prop("checked", true);
            });

        } else {
            $(ele).each(function() {
                $(this).prop("checked", false);
            });
        }

    });
}

/*
    tab选项
*/

function getTabs(obj, clss, con) {
    $(obj).bind("click", function() {
        $(this).addClass(clss).siblings().removeClass(clss);
        if (typeof con == "String") {
            $(con).hide();
            $(con).eq($(this).index()).show();
        }


    });
}

/*
重置Iframe高度  
直接调用 
getHeight();
*/

function getHeight() {
    var cH = document.body.offsetHeight;
    parent.getHeight(cH);

}

function resetFrameHeight(height) {
    if (height < 0) {
        return;
    }
    var obj = document.getElementById("iframe");
    if (obj != null) {
        obj.style.height = height + "px";
    }

}


//计算 累加 累减
function getCompute(minus, plus, mount) {


    var regNum = /^\+?(0|[1-9][0-9]*)$/;
    $(mount).bind("blur", function() {
        if (regNum.test($("#mount").val()) == false) {
            alert("这不是一个有效数字");
            return false;
        } else {
            alert(1)
        }
    });
    $(minus).bind("click", function() {
        var iVal = $("#mount").val();
        iVal--;
        if (iVal > 0) {
            $(mount).val(iVal);
        } else {
            $(mount).val(0)
        }

    });
    $(plus).bind("click", function() {
        var iVal = $(mount).val();
        iVal++;
        $(mount).val(iVal);

    });
}
