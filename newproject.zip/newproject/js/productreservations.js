'use strict';
$(function() {

    // 下拉框初始化
    // $('#basic').selectric();
    // $('#basic2').selectric();

    //成人 、儿童 计算
    getCompute("#c-minus", "#c-plus", "#c-mount");
    getCompute("#e-minus", "#e-plus", "#e-mount");


    	//selectric 监听打开 点击 关闭状态事件 

    // $('#basic')
    //     .on('selectric-before-open', function() {
    //         alert('Before open');
    //     })
    //     .on('selectric-before-close', function() {
    //         alert('Before close');
    //     })
    //     // You can bind to change event on original element
    //     .on('change', function() {
    //         alert('Change');
    //     });

    // // Or, with plugin options
    // $('#basic').selectric({
    //     onOpen: function() {
    //         alert('Open');
    //     },
    //     onChange: function() {
    //         alert('Change');
    //     },
    //     onClose: function() {
    //         alert('Close');
    //     }
    // });
    
    	


		// eg: 获取值
		// $('#basic').selectric().on('change', function() {
		// 	alert( $(this).val() )
		// });
		for(var i=0;i<area_array.length;i++){
			if( area_array[i] != undefined ){
				$('#basic').append('<option>' +area_array[i]+'</option>');	
				for( var k=0;k<sub_array[i].length;k++ ){
					$('#basic2').append('<option>' +area_array[i][k]+'</option>');	
				}
			}

		}
			
			
		// }
		// for(var j=0;j<area_array.length;j++){
		// 	if( area_array[j] != undefined ){
		// 		$('#basic2').append('<option>' +area_array[j]+'</option>');		
		// 	}
			
			
		// }

		//动态添加
		
		// $('#basic').selectric('refresh');
});

function checkUserInfo(){
	var user = $("#username"),
		mobile = $("#mobile"),
		email = $("#email"),
		flag = 0;
		
	if( $(user) && $(user) == ""  ){
		$(user).siblings("i").text("用户名不能为空");
		$(user).addClass("active");
		return false;
	}else if( $(user).val().length>20 || $(user).val().length<0 ){
		alert($(user).val().length)
		$(user).siblings("i").text("用户名长度在20字符以内");
		$(user).addClass("active");
		return false;
	}else{
		flag++;
		$(user).siblings("i").text("");
		$(user).removeClass("active");
		alert(flag)
		
	}

	// else if( REG.regMobile.test($(mobile)) == false ){
	// 	$(mobile).siblings("i").text("格式不对");
	// 	return false;
	// }
	if( $(mobile) && $(mobile) == ""  ){
		$(mobile).siblings("i").text("手机号不能为空");
		$(mobile).addClass("active");
		return false;	
	}else{
		flag++;
		$(mobile).siblings("i").text("");
		$(mobile).removeClass("active");
		alert(flag)
		
	}
	if( email && email == ""  ){
		$(email).siblings("i").text("邮箱不能为空");
		$(email).addClass("active");
		return false;	
	}else if( REG.regEmail.test(email) == false ){
		$(email).siblings("i").text("格式不对");
		$(email).addClass("active");
		return false;
	}else{
		flag++;
		$(email).removeClass("active");
		alert(flag)
		
	}
	if( flag == 3 ){
		alert(flag)
		location.href="www.baidu.com";
		return true;
	}
		
	



	
}
