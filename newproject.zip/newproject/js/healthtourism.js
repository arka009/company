$(function() {
    getShowHide("#city_more");
    getShowHide("#destination");

    $("#tab ul li").click(function(){
    	
    	$(this).siblings().find("a").removeClass("active");
    	$(this).find("a").addClass("active");
    	
    	$(this).css("color","red").siblings().css("color","blue")

    	$(".right .con").slideUp();
    	$(".right .con").eq($(this).index()).slideDown();
    });

    $.each($("table .last"),function(){
    	if ($(this).find("td").eq(2).text().length==2){
    
	    	$(this).find("td").eq(2).css({
	    		"font-size":"24px"
	    	});
    	}	
    });



    // 分页 

     $("div.holder").jPages({
            containerID: "itemContainer",
            previous :"上一页",
            next :"下一页",
             perPage:1,
               callback    : function( pages, items){
               		$("#countpage").html(pages.count)
               }
     });

        /* when button is clicked */
        $("#jumptopage").click(function() {
            /* get given page */
            var page = parseInt($("input").val());

            /* jump to that page */
            $("div.holder").jPages(page);

        });
    

});

function getShowHide(obj) {
        var flag = false;
        $(obj).click(function() {

            if (flag) {
                $(this).parent().siblings(".last").slideUp();
                $(this).removeClass("more");
                flag = false;
            } else {
                $(this).parent().siblings(".last").slideDown();
                $(this).addClass("more");
                flag = true;

            }

        });
    }
