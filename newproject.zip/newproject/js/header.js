$(function(){
    var dtheader= $("<div class='dtheader clearfix'></div>");
            var header = '<div class="container">'+
        '<div class="header">'+
            '<div class="weblogo">'+
                '<a href=""><img src="../images/logo.jpg"></a>'+
            '</div>'+
            '<div class="arealogin fl">'+
                '<span>北京</span>'+
                '<div class="area">'+
                    '<a href="javascript:;">北京</a>'+
                    '<a href="javascript:;">北海</a>'+
                    '<a href="javascript:;">烟台</a>'+
                    '<a href="javascript:;">廊坊</a>'+
                    '<a href="javascript:;">洛阳</a>'+
                    '<a href="javascript:;">杭州</a>'+
                '</div>'+
            '</div>'+
            '<ul>'+
                '<li><a href="">健康旅游</a><span></span></li>'+
                '<li><a href="">服务团队</a></li>'+
                '<li><a href="">新绎故事</a></li>'+
                '<li><a href="">健康周边</a></li>'+
            '</ul>'+
            '<div class="login_reg fl">'+
                '<a href="" class="alogin">登陆</a>|'+
                '<a href="">注册</a>'+
                '<!-- <a href="" class="logining">长大懂事</a> -->'+
            '</div>'+
            '<div class="order fl">'+
                '<div class="uname">'+
                    '<span id="uname">张懂事</span>'+
                    '<ol>'+
                        '<li><a href="#">服务团队</a></li>'+
                        '<li><a href="#">新绎故事</a></li>'+
                        '<li><a href="#">健康周边</a></li>'+
                    '</ol>'+
                '</div>'+
            '</div>'+
            '<div class="wchat fl">'+
                '<a href="javascript:;"><em></em></a>'+
                '<span>|&nbsp;&nbsp;4008001234</span>'+
            '</div>'+
        '</div>'+
    '</div>';
        $(dtheader).html(header)
        $("body").prepend(dtheader)
     
   $(".uname").hover(function() {
        $(this).find("ol").show();
    }, function() {
        $(this).find("ol").hide();
    });
    $(".wchat a").hover(function() {
        $(this).find("em").show();
    }, function() {
        $(this).find("em").hide();
    });
    var areaFlag = false;
    $(".arealogin").click(function(){
        if( areaFlag ){
             $(".arealogin span").removeClass("onfocus");
             $(".arealogin .area").hide();
             areaFlag = false;
         }else{
            $(".arealogin span").addClass("onfocus");
            $(".arealogin .area").show();
            areaFlag = true;
         }
        
    })
    $(".arealogin .area").find("a").click(function(){
         $(".arealogin span").text( $(this).text() );
         $(".arealogin .area").hide();
    })

})