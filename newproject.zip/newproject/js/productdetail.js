 $(function() {


     // $("#result").hide(); //将保存结果的DIV隐藏
     var dlLen = $("#itemContainer>dl");

     for (var i = 0; i < dlLen.length; i++) {
         $("#itemContainer>dl").eq(i).find("li").eq(0).find("div").eq(1).attr("id", "star" + i);
         $("#itemContainer>dl").eq(i).find("li").eq(0).find("div").eq(0).find("span").attr("id", "result" + i);
         var star = $("#itemContainer>dl").eq(i).find("li").eq(0).find("div").eq(1).attr("id");
         var result = $("#itemContainer>dl").eq(i).find("li").eq(0).find("div").eq(0).find("span").attr("id");

         $("#" + star).raty({
             number: 5, //多少个星星设置
             score: 0, //初始值是设置
             targetType: 'number', //类型选择，number是数字值，hint，是设置的数组值
             path: '../bower_components/jquery-raty/img',

             size: 24,
             starHalf: 'star-half.png',
             starOff: 'star-off.png',
             starOn: 'star-on.png',
             target: '#' + result,
             cancel: false,
             targetKeep: true,
             precision: true, //是否包含小数
             click: function(score, evt) {
                 $("#result").show();
                 alert('ID: ' + $(this).attr('id') + "\nscore: " + score + "\nevent: " + evt.type);
             }
         });
     }


     // 分页 

     $("div.holder").jPages({
         containerID: "itemContainer",
         previous: "上一页",
         next: "下一页",
         perPage: 1,
         callback: function(pages, items) {
             $("#countpage").html(pages.count)
         }
     });

     /* when button is clicked */
     $("#jumptopage").click(function() {
         /* get given page */
         var page = parseInt($("input").val());

         /* jump to that page */
         $("div.holder").jPages(page);

     });



     $.each($("table .last"), function() {
         if ($(this).find("td").eq(2).text().length == 2) {

             $(this).find("td").eq(2).css({
                 "font-size": "30px"
             });
         }
     });


     $("#location li").not(".last").find("span").click(function() {
         $(this).parent().addClass("active").siblings().removeClass("active");
     });
     var json = {
         p1: ['D01', 'D01', 'D01', 'D01', 'D01', 'D01', 'D01', 'D01', 'D01', 'D01', 'D01', 'D01', 'D01', 'D01'],
         p2: ['乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐', '乌鲁木齐']
     }
     var str = '';
     for (var ii = 1; ii < 15; ii++) {
         str = '<li>' +
             '<span></span>' +
             '<p>' + json.p1[ii] + '</p>' +
             '<p>' + json.p2[ii] + '</p>' +
             '</li>';
         if (ii == 8) {
             var str2 = '<li class="last"></li>';
             $("#location ul").append(str2)
         }


         $("#location ul").append(str)
         if (ii > 8) {

             $("#location").css("height", "294px");
             $("#location li").not(".last").eq(6).nextAll().css({
                 "position": "absolute",
                 "bottom": "-142px",


             });
             $("#location li").not(".last").eq(7).css({

                 "right": "0px"
             });
             $("#location li").not(".last").eq(8).css({

                 "right": "122px"
             });
             $("#location li").not(".last").eq(9).css({

                 "right": "244px"
             });
             $("#location li").not(".last").eq(10).css({

                 "right": "366px"
             });
             $("#location li").not(".last").eq(11).css({

                 "right": "488px"
             });
             $("#location li").not(".last").eq(12).css({

                 "right": "610px"
             });
             $("#location li").not(".last").eq(13).css({

                 "right": "732px"
             });
         }
     }
     








         var g = function(id) {
             return document.getElementById(id);
         }
     var getBodyW = function() {
         return document.body.offsetWidth;
     };
     var getBodyH = function() {
         return document.body.offsetHeight;
     };
     var getElTop = function(el) {
         return el.offsetTop;
     };



     var scrollTopTo = function(to) {
         var start = document.body.scrollTop;
         fx(function(now, type) {
             window.scroll(0, now);
         }, start, to);
     }

     var show = function(obj) {

         var top = getElTop(g(obj));
         scrollTopTo(top);
         //  滚动到当前的位置
     }

     var $g = $(g('timelinenav'));

     $g.find("li").eq(0).addClass("active");
     $g.find("li").click(function() {

        // alert(show("d" + $(this).index()));

         $(this).addClass("active").siblings().removeClass("active");
     });

     $("#location li").not(".last").click(function() {
         alert(show("d" + $(this).index()));
         show("d" + $(this).index());
         $(this).parent().addClass("active").siblings().removeClass("active");
     });

     window.onscroll = function() {

         var top = document.body.scrollTop;

         if (top > 200) {
             g('timelinenav').style.position = 'fixed';
             // g('timelinenav').style.left = (getBodyW()-960)/2+ 'px';
             g('timelinenav').style.left = 30 + 'px';
             // g('timelinenav').style.top  = '60px';
         } else {
             g('timelinenav').style.position = '';
             g('timelinenav').style.left = '';
             g('timelinenav').style.top = '';
         }


     }
     var flag = false;
     $(".content li p").click(function() {
         $(this).siblings(".productimg").toggle();
     });




     // var locationLi=$("#location li").not(".last");
     //         if( locationLi.length>7 ){
     //                $("#location li").not(".last").eq(7).nextAll().css({
     //                    "background":"none"
     //                });
     //                $("#location li").not(".last").eq(13).css({
     //                    "background":"url('../images/dotted_sprite_li.png') no-repeat -30px 0"
     //                })
     //         }
     // $("#location li").not(".last").eq(7).nextAll().hide();
 });
