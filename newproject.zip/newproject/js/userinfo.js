$(function() {
    var userlistFlag = false;
    $("#userlist h1").click(function() {
        if ($(this).next("div").length > 0) {
            if (userlistFlag) {
                
                $(this).find("a").removeClass("active");
                $(this).siblings("div").slideDown()
                userlistFlag = false;
            } else {

                $(this).find("a").addClass("active");
                $(this).siblings("div").slideUp()
                userlistFlag = true;
            }
        }

    });
    $("#userlist li a").click(function(){
    	$("#userlist li").find("a").removeClass("active");
    	$(this).addClass("active");
    })
});

function updatePhone(th) {

    $("#mobile").attr("readonly", false);
    $("#mobile").addClass("border");
    $(th).text("确定");
    $(th).attr("onclick", "submitUpdatePhone()")
}

function updateEmail(th) {
    $("#email").attr("readonly", false);
    $("#email").addClass("border");
    $(th).text("确定");
    $(th).attr("onclick", "submitUpdateEmail()")
}

function submitUpdateEmail() {
    $("#email").attr("readonly", true);
    $("#email").removeClass("border");
    $("#supplementalemail").text("补充邮箱");
    // $.ajax({
    // 	type : "post",
    // 	url : "http://localhost:8080/web/newUser/updateEmail.do",
    // 	data:"phone="+$("#eMail").val(),
    // 	success:function(e){
    // 		if(e=="1"){
    // 			$("#eMail").val($("#eMail").val());
    // 			$("#eMail").addClass("noBorderText");
    // 			$("#editEmailButton").text("补充邮箱");
    // 			$("#editEmailButton").attr("onclick","updateEmail(this)");
    // 		}

    // 	}
    // })

}

function submitUpdatePhone() {
    $("#mobile").attr("readonly", true);
    $("#mobile").removeClass("border");
    $("#modify").text("修改");
    $("#modify").attr("onclick", "updatePhone(this)");
    // $.ajax({
    // 	type : "post",
    // 	url : "http://localhost:8080/web/newUser/updatePhone.do",
    // 	data:"phone="+$("#mobile").val(),
    // 	success:function(e){
    // 		if(e=="1"){
    // 			$("#mobile").val($("#mobile").val());
    // 			$("#mobile").addClass("noBorderText");
    // 			$("#editPhoneButton").text("修改");
    // 			$("#editPhoneButton").attr("onclick","updatePhone(this)");
    // 		}

    // 	}
    // })

}

function saveUserInformation() {
    $("input[name='editname']").attr("readonly", true);
    $("input[name='editname']").removeClass("border");
    var str = '<span id="sex">男</span>';
    $("#sex").html(str);
    $("#edit").attr("onclick", "editUserInformation()");
    $("#edit").text("编辑")
        //var sex=$("input[name='sex']:checked").val();
        // $.ajax({
        // 	type : "post",
        // 	url : "http://localhost:8080/web/newUser/saveUserInformation.do",
        // 	data:"nickName"+$("#nickName").val()+"&name="+$("#name").val()+"&sex="+sex+"&birthday="+$("#birthday").val()+"&goCity="+$(".city").val(),
        // 	success:function(e){
        // 		if(e=="1"){
        // 			$("#nickName").addClass("noBorderText");
        // 			$("#name").addClass("noBorderText");
        // 			$("#birthday").addClass("noBorderText");

    // 			$("#nickName").val($("#nickName").val());
    // 			$("#name").val($("#name").val());
    // 			$("#sexDiv").html('性<span style="margin-left:2em;">别：<span style="margin-left:2em;">'+sex+'</span>');
    // 			$("#provAndCityDiv").html('常用出发城市：<span id="gocity">'+$(".city").val()+'</span>');
    // 			$("#birthday").val($("#birthday").val());

    // 			$("#editButton").val("编辑");
    // 			$("#editButton").attr("onclick","editUserInformation()");
    // 		}

    // 	}
    // })
}

function editUserInformation() {
    $("input[name='editname']").attr("readonly", false);
    $("input[name='editname']").addClass("border");
    var str = '<input class="radio" type="radio" name="sex" value="男" checked="checked">男<input  class="radio" type="radio" name="sex" value="女" >女';
    $("#sex").html(str);
    $("#edit").attr("onclick", "saveUserInformation()");
    $("#edit").text("保存")
}
