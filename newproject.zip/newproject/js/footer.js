$(function(){
    var dtfooter= $("<div class='dtfooter'></div>");
            var footer = '<div class="bottom">'+
        '<div class="container clearfix">'+
            '<dl class="clearfix">'+
                '<dt>'+
                    '<img src="../images/indexlogo.png">'+
                '</dt>'+
                '<dd>'+
                    '<p class="first">全球精品旅行体验 & 健康生活方式</p>'+
                    '<p>中国 No.1 精品旅行预订网站</p>'+
                    '<p>中国首家健康旅行平台</p>'+
                    '<p>中国首家A股上市健康旅游企业（北部湾旅 603869）</p>'+
                    '</p>'+
                '</dd>'+
            '</dl>'+
            '<div class="clearfix">'+
                '<dl class="erweima">'+
                    '<dd>'+
                        '<img src="../images/erweima.jpg">'+
                    '</dd>'+
                '</dl>'+
                '<dl>'+
                    '<dd>'+
                        '<p class="first">联系我们</p>'+
                        '<p class="first">010-80509462</p>'+
                        '<p>zhanghlk@enn.cn</p>'+
                        '<p>关于我们</p>'+
                        '</p>'+
                    '</dd>'+
                '</dl>'+
                '<dl>'+
                    '<dd>'+
                        '<p class="first">服务标准</p>'+
                        '<p>我们不做走马观花的带路人，我们将成为您身心的陪伴者！</p>'+
                    '</dd>'+
                '</dl>'+
                '<dl>'+
                    '<dd>'+
                        '<p class="first">友情链接</p>'+
                        '<p>新奥集团</p>'+
                        '<p>北部湾旅游</p>'+
                        '<p>来游吧</p>'+
                    '</dd>'+
                '</dl>'+
            '</div>'+
            '<div class="reg">'+
                '<h2>欢迎来到新绎旅游，快来<a href="">注册</a>吧！</h2>'+
            '</div>'+
            '<div class="copy">Copyright © 2006-2016 新绎旅游</div>'+
        '</div>'+
    '</div>';
        $(dtfooter).html(footer)
        $("body").append(dtfooter)
     
   

})