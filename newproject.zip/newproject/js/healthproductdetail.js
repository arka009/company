'use strict';
$(function() {

    // 点击图片放大区域
    var dd = $("#pic").find("dd"),
        dt = $("#pic").find("dt");
        $(dt).find("img").fadeOut();	
        setTimeout(function(){
        	$(dt).find("img").fadeIn();	
        },300)
        
    $(dd).each(function() {
        $(this).bind("click", function() {
            var imgSrc = $(this).find("img").attr("src");
            $(this).addClass("active").siblings().removeClass("active");
            $(dt).find("img").attr("src", imgSrc);
            $(dt).find("img").stop().fadeOut();
            $(dt).find("img").fadeIn();
            // if(imgSrc.indexOf("/")>0){
            // 	 var imgName=imgSrc.substring(imgSrc.lastIndexOf("/")+1,imgSrc.length);
            // 	 // alert(imgName)
            // 	 $(dt).find("img").attr("src", imgName);
            // }

        });
    });

    //购买数量
    getCompute("#minus", "#plus", "#mount");
    

    //详情、须知 
    $("#healthtab").find("li").bind("click", function() {
        $(this).addClass("active").siblings().removeClass("active");
        $(".detail-dis-tab").fadeOut();
        $(".detail-dis-tab").eq($(this).index()).fadeIn();
    });



});
